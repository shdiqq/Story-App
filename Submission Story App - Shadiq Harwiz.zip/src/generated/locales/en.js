// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  s0832aaca8cfaacf2: `Created date`,
  s749c72374d54863f: `Close`,
  s772ce5f935d58e37: `Description`,
  sdf27102dcea9ece7: `Created by Sadiq Harwiz`,
  sef49b2c68fd1e332: `Name`,
  sf9a862bfd829397e: `Dashboard`,
  sfae357d460dcc835: `Add Story`,
};
