// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */
/* eslint-disable @typescript-eslint/no-explicit-any */

export const templates = {
  s0832aaca8cfaacf2: `Date de création`,
  s749c72374d54863f: `Fermé`,
  s772ce5f935d58e37: `Description`,
  sdf27102dcea9ece7: `Réalisé par Sadiq Harwiz`,
  sef49b2c68fd1e332: `Nom`,
  sf9a862bfd829397e: `Tableau de bord`,
  sfae357d460dcc835: `Ajouter des histoires`,
};
